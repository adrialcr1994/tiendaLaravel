<form action="<?php echo e(url('/listar')); ?>" method="POST"> <!--Enviamos los datos a la url que va a mostrar los datos que tengamos por pantalla-->

<?php echo csrf_field(); ?> <!--Necesaria para evitar errores de seguridad-->
<h1>hola</h1>

<input type="submit">

</form><?php /**PATH C:\xampp\htdocs\laravel-2\resources\views/index1_1.blade.php ENDPATH**/ ?>