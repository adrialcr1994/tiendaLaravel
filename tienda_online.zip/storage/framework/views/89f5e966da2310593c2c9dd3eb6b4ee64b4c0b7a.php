<?php if(Auth::check()): ?>
<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded='false'>
        <i class="material-icons">perm_identity</i><?php echo e(Auth::user()->user); ?><span class="caret"></span>
    </a>
    <ul class="dropdown-menu" role="menu">
        <li><a href="<?php echo e(route('logout')); ?>">Finalizar Sesion</a></li>
    </ul>
</li>

<?php else: ?>

<li class="dropdown">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-expanded='false'>
        <i class="material-icons">perm_identity</i><span class="caret"></span>
    </a>
    <ul class="dropdown-menu" role="menu">
        <li><a href="<?php echo e(route('login-get')); ?>">Iniciar Sesion</a></li>
    </ul>
</li>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\tienda_online\resources\views/menu-usuario.blade.php ENDPATH**/ ?>