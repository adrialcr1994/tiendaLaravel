<?php $__env->startSection('content'); ?>

<div class="container text-center">
    <div class="page-header">
        <h1><i class="fa fa-shopping-cart"></i>Detalles del pedido</h1>
    </div>
    <div class="page">
        <div class="table-responsive">
            <h3>Datos del usuario</h3>
            <table class="table table-striped table-hover table-borderes">
            <tr>
                    <td>Nombre:</td>
                    <td><?php echo e(Auth::user()->nombre); ?></td>
                </tr>
                <tr>
                    <td>Nick:</td>
                    <td><?php echo e(Auth::user()->nick); ?></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><?php echo e(Auth::user()->email); ?></td>
                </tr>
                <tr>
                    <td>Direccion:</td>
                    <td><?php echo e(Auth::user()->direccion); ?></td>
                </tr>
            </table>
        </div>
        <div class="table-responsive">
            <h3>Datos del pedido</h3>
            <table class="table table-striped table-hover table-borderes">
                <tr>
                    <th>Producto:</th>
                    <th>Precio:</th>
                    <th>Cantidad:</th>
                    <th>Subtotal:</th>
                </tr>

                <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($item->nombre_producto); ?></td>
                    <td><?php echo e(number_format($item->precio_producto,2)); ?></td>
                    <td><?php echo e($item->cantidad); ?></td>
                    <td><?php echo e(number_format($item->precio_producto * $item->cantidad,2)); ?></td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
            <hr>
                <h3>
                    <span class="label label-success">
                        Total a pagar: <?php echo e(number_format($total,2)); ?> €
                    </span><hr>
                    <a href="<?php echo e(route('mostrar_carrito')); ?>" class="btn btn-primary"><i class="fa fa-chevron-circle-left"></i> Volver</a>
                    <a href="#" class="btn btn-warning">Proceder el pago <i class="fa fa-chevron-circle-right"></i></a>
                </h3>
        </div>
    </div>
</div>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienda_online\resources\views/detalles_pedido.blade.php ENDPATH**/ ?>