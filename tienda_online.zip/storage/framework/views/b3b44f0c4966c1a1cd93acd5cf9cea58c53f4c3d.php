<!--Vista que muestra los datos que ha recibido-->
<p>numero</p>

<p><?php echo e($numero); ?></p><!--Esta variable tiene el valor que le hemos dado en el controlador--><?php /**PATH C:\xampp\htdocs\laravel-2\resources\views/index2.blade.php ENDPATH**/ ?>