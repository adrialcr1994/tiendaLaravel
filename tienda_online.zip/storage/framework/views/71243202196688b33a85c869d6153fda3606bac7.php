<!--es una herencia-->

<!--Nombre que va a tener esta seccion-->
<?php $__env->startSection('content'); ?>


<h1>Listar Productos</h1>
<div class="container-fluid"></div>
<div class="row bg-primary p-4" style="width: 100%">
<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



<div class="col-md-3 d-flex align-items-stretch">
<div class="card mb-3 shadow-lg p-3 mb-5 bg-white rounded" style="width: 18rem;">
  <img class="card-img-top" src="<?php echo e(url('assets/imagenes/'  .$dato->imagen_producto)); ?>" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title" style="text-align:center;"><?php echo e($dato->descripcion_producto); ?></h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
  </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>
</div>
<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienda_online\resources\views/index1_2.blade.php ENDPATH**/ ?>