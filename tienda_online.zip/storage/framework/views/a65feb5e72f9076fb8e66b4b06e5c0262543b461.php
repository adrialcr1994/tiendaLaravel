<!--es una herencia-->

<!--Nombre que va a tener esta seccion-->
<?php $__env->startSection('content'); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.2/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
    <script type="text/javascript" src="<?php echo e(url('../public/js/jquery-3.4.1.js')); ?>"></script>
    <title>Document</title>
</head>
<body>
    <div class="container-fluid text-center">
        <div class="page-header">
            <h1><i class="fa fa-shopping-cart"></i>Carrito Compras</h1>
        </div>

        <div class="table-cart">
        <?php if(count($carrito)): ?>

        <p>
            <a href="<?php echo e(route('vaciar_carrito')); ?>" class="btn btn-danger"><i class="fa fa-trash"></i> Vaciar Carrito</a>
        </p>
            <div class="table-responsive">
                <table class="table table-striped table-hover table-bordered">
                    <thead>
                        <tr>
                            <th>Imagen</th>
                            <th>Producto</th>
                            <th>Precio</th>
                            <th>Cantidad</th>
                            <th>Subtotal</th>
                            <th>Quitar</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><img src="<?php echo e(url('assets/imagenes/'  .$item->imagen_producto)); ?>" height="50" weith="50"></td>
                            <td><?php echo e($item->nombre_producto); ?></td>
                            <td><?php echo e(number_format($item->precio_producto,2)); ?> €</td>
                            
                            <td>
                                <input 
                                    type="number"
                                    min="1"
                                    max="100"
                                    value="<?php echo e($item->cantidad); ?>"
                                    id="producto_<?php echo e($item->codigo_producto); ?>"
                                >
                            <?php if($item->cantidad > $item->stock): ?>

                            <span style="color: red;">No Hay Suficiente Stock en tienda</span>

                            <a 
                                    href="#" 
                                    class="btn btn-warning btn-update-item"
                                    data-href="<?php echo e(route('actualizar_item', $item->codigo_producto)); ?>"
                                    data-id="<?php echo e($item->codigo_producto); ?>"
                                    ><i class="fas fa-sync-alt"></i>
                                
                                </a>     
                            
                            <?php else: ?>
                           
                                <a 
                                    href="#" 
                                    class="btn btn-warning btn-update-item"
                                    data-href="<?php echo e(route('actualizar_item', $item->codigo_producto)); ?>"
                                    data-id="<?php echo e($item->codigo_producto); ?>"
                                    ><i class="fas fa-sync-alt"></i>
                                
                                </a>
                            
                            <?php endif; ?>
                            </td>
                            <td><?php echo e(number_format($item->precio_producto * $item->cantidad,2)); ?> €</td>
                            <td>
                                <a href="<?php echo e(route('borrar_item', $item->codigo_producto)); ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table><hr>
                    <h3>
                        <span class="label label-success">Total a pagar: <?php echo e(number_format($total,2)); ?> €</span>
                    </h3>
            </div>
            <?php else: ?>
                <h3><span class="label label-warning">No hay productos en el carrito</span></h3>
            <?php endif; ?>

            <hr>
            <p>
                
                <a href="<?php echo e(route('inicio')); ?>" class="btn btn-primary"><i class="fa fa-chevron-circle-left"></i> Seguir Comprando</a>
                
                <?php if($finalizar==false): ?>
                <a href="#" class="btn btn-warning" hidden>Finalizar Compra <i class="fa fa-chevron-circle-right"></i></a>
                <?php else: ?>
                <a href="<?php echo e(route('detalle-pedido')); ?>" class="btn btn-warning">Finalizar Compra <i class="fa fa-chevron-circle-right"></i></a>
                <?php endif; ?>
            </p>
        </div>
    </div>
</body>

<script type="text/javascript" src="<?php echo e(url('../public/js/main.js')); ?>"></script>
</html>

<?php echo $__env->make('principal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tienda_online\resources\views/carrito.blade.php ENDPATH**/ ?>