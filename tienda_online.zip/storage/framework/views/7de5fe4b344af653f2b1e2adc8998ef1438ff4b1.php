<form action="<?php echo e(url('/adios')); ?>" method="POST"> <!--Enviamos los datos a la url que va a mostrar los datos que tengamos por pantalla-->

<?php echo csrf_field(); ?> <!--Necesaria para evitar errores de seguridad-->
<h1>hola</h1>

<input name="dato">

</form><?php /**PATH C:\xampp\htdocs\laravel-2\resources\views/index.blade.php ENDPATH**/ ?>