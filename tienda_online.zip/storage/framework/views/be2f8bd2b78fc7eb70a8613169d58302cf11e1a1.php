
<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

<div class="container-fluid"></div>
<div class="row bg-primary p-4" style="width: 100%">
<?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dato): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>



<div class="col-md-3 d-flex align-items-stretch">
<div class="card mb-3 shadow-lg p-3 mb-5 bg-white rounded" style="width: 18rem;">
  <img class="card-img-top" src="<?php echo e(url('assets/imagenes/'  .$dato->imagen_producto)); ?>" alt="Card image cap">
  <div class="card-body">
    <h5 class="card-title" style="text-align:center;"><?php echo e($dato->descripcion_producto); ?></h5>
    <p class="card-text">Some quick example text to build on the card title and make up the bulk of the card's content.</p>
  </div>
  </div>
</div>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
</div><?php /**PATH C:\xampp\htdocs\laravel-2\resources\views/index1_2.blade.php ENDPATH**/ ?>